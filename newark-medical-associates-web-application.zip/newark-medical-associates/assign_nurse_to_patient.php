<?php
require_once "includes/header.php"
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        require_once "includes/sidebar.php"
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                require_once "includes/navbar.php"
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="container">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Assign/Remove a Nurse to a Patient</h1>
                            <a href="view_assignment.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-users fa-sm text-white-50"></i> View All Assigns</a>

                        </div>

                        <!-- Content Row -->
                        <?php

                        if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['assign_nurse'])) {
                            // Assume you have a valid database connection named $conn

                            // Get the selected patient and nurse IDs
                            $patientId = $_POST['patient_id'];
                            $nurseId = $_POST['nurse_id'];

                            // Update patient_assignments table to set has_nurse to 'yes'
                            $updatePatientAssignmentQuery = "UPDATE patient_assignments SET has_nurse = 'yes' WHERE patient_id = :patientId";
                            $stmtUpdatePatientAssignment = $conn->prepare($updatePatientAssignmentQuery);
                            $stmtUpdatePatientAssignment->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                            $stmtUpdatePatientAssignment->execute();


                            // Insert a new entry into nurse_assignments table
                            $insertNurseAssignmentQuery = "INSERT INTO nurse_assignments (patient_id, nurse_id) VALUES (:patientId, :nurseId)";
                            $stmtInsertNurseAssignment = $conn->prepare($insertNurseAssignmentQuery);
                            $stmtInsertNurseAssignment->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                            $stmtInsertNurseAssignment->bindParam(':nurseId', $nurseId, PDO::PARAM_INT);
                            $stmtInsertNurseAssignment->execute();

                            // Redirect or display a success message
                            header("Location: assign_patient_to_room.php");
                            exit();
                        }
                        ?>



                        <form action="assign_nurse_to_patient.php" method="POST">
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <!-- Select patient with assigned doctor -->
                                    <label for="patient_id">Select Patient:</label>
                                    <select class="form-control rounded-lg" name="patient_id" required>
                                        <?php
                                        // Fetch patients with doctor assigned but no nurse assigned
                                        $fetchPatientsQuery = "SELECT pa.patient_id, p.first_name, p.last_name 
                              FROM doctor_assignments da
                              JOIN patient_assignments pa ON da.patient_id = pa.patient_id
                              JOIN patients p ON pa.patient_id = p.patient_id
                              WHERE pa.has_doctor = 'yes' 
                              AND pa.patient_id NOT IN (SELECT patient_id FROM nurse_assignments WHERE has_nurse = 'yes')";
                                        $stmtPatients = $conn->prepare($fetchPatientsQuery);
                                        $stmtPatients->execute();
                                        $patients = $stmtPatients->fetchAll(PDO::FETCH_ASSOC);

                                        if ($patients) {
                                            foreach ($patients as $patient) {
                                                echo "<option value='{$patient['patient_id']}'>{$patient['first_name']} {$patient['last_name']}</option>";
                                            }
                                        } else {
                                            echo "<option value='' disabled>No patients available</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <!-- Select nurse to assign -->
                                    <label for="nurse_id">Select Nurse:</label>
                                    <select class="form-control rounded-lg" name="nurse_id" required>
                                        <?php
                                        // Fetch nurses
                                        $fetchNursesQuery = "SELECT * FROM medical_staff WHERE job_type = 'Nurse'";
                                        $stmtNurses = $conn->prepare($fetchNursesQuery);
                                        $stmtNurses->execute();
                                        $nurses = $stmtNurses->fetchAll(PDO::FETCH_ASSOC);

                                        foreach ($nurses as $nurse) {
                                            echo "<option value='{$nurse['staff_id']}'>{$nurse['first_name']} {$nurse['last_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Submit button -->
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <button type="submit" class="btn btn-primary btn-user btn-block" name="assign_nurse">Assign Nurse to Patient</button>
                            </div>
                        </form>

                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            require_once "includes/footernote.php"
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php
    require_once "includes/footer.php"
    ?>

</body>

</html>