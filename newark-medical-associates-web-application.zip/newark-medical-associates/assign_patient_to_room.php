<?php
require_once "includes/header.php"
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        require_once "includes/sidebar.php"
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                require_once "includes/navbar.php"
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="container">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Assign/Remove a Patient to a Room/Bed</h1>
                            <a href="assign_doctor_to_patient.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-users fa-sm text-white-50"></i> Assign/Remove a Doctor to a Patient</a>

                        </div>

                        <!-- Content Row -->
                        <?php
                        if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['assign_room'])) {
                            // Assume you have a valid database connection named $conn

                            // Get the selected patient ID
                            $patientId = $_POST['patient_id'];

                            // Check if the patient is not already assigned
                            $checkAssignmentQuery = "SELECT * FROM patient_assignments WHERE patient_id = :patientId";
                            $stmtCheckAssignment = $conn->prepare($checkAssignmentQuery);
                            $stmtCheckAssignment->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                            $stmtCheckAssignment->execute();

                            if ($stmtCheckAssignment->rowCount() === 0) {
                                // Patient is not assigned, proceed with assigning

                                // Check for an available room
                                $fetchAvailableRoomQuery = "SELECT * FROM rooms WHERE status = 'Available' AND available_beds > 0 LIMIT 1";
                                $stmtAvailableRoom = $conn->prepare($fetchAvailableRoomQuery);
                                $stmtAvailableRoom->execute();
                                $availableRoom = $stmtAvailableRoom->fetch(PDO::FETCH_ASSOC);

                                if ($availableRoom) {
                                    // Assign the patient to the room
                                    $roomId = $availableRoom['room_id'];

                                    // Your logic to insert into patient_assignments table
                                    $assignPatientQuery = "INSERT INTO patient_assignments (patient_id, room_id, has_doctor, has_nurse) VALUES (:patientId, :roomId, :hasDoctor, :hasNurse)";
                                    $stmtAssignPatient = $conn->prepare($assignPatientQuery);
                                    $stmtAssignPatient->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                                    $stmtAssignPatient->bindParam(':roomId', $roomId, PDO::PARAM_INT);

                                    // Check if the patient has a doctor assignment
                                    $checkDoctorAssignmentQuery = "SELECT * FROM doctor_assignments WHERE patient_id = :patientId";
                                    $stmtCheckDoctorAssignment = $conn->prepare($checkDoctorAssignmentQuery);
                                    $stmtCheckDoctorAssignment->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                                    $stmtCheckDoctorAssignment->execute();
                                    $hasDoctor = $stmtCheckDoctorAssignment->rowCount() > 0 ? 'yes' : 'no';

                                    // Check if the patient has a nurse assignment
                                    $checkNurseAssignmentQuery = "SELECT * FROM nurse_assignments WHERE patient_id = :patientId";
                                    $stmtCheckNurseAssignment = $conn->prepare($checkNurseAssignmentQuery);
                                    $stmtCheckNurseAssignment->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                                    $stmtCheckNurseAssignment->execute();
                                    $hasNurse = $stmtCheckNurseAssignment->rowCount() > 0 ? 'yes' : 'no';

                                    $stmtAssignPatient->bindParam(':hasDoctor', $hasDoctor, PDO::PARAM_STR);
                                    $stmtAssignPatient->bindParam(':hasNurse', $hasNurse, PDO::PARAM_STR);

                                    $stmtAssignPatient->execute();

                                    // Update the number of available beds in the rooms table
                                    $updateAvailableBedsQuery = "UPDATE rooms SET available_beds = available_beds - 1 WHERE room_id = :roomId";
                                    $stmtUpdateAvailableBeds = $conn->prepare($updateAvailableBedsQuery);
                                    $stmtUpdateAvailableBeds->bindParam(':roomId', $roomId, PDO::PARAM_INT);
                                    $stmtUpdateAvailableBeds->execute();

                                    // Update the room status if the available beds reach 0
                                    if ($availableRoom['available_beds'] - 1 === 0) {
                                        $updateRoomStatusQuery = "UPDATE rooms SET status = 'Occupied' WHERE room_id = :roomId";
                                        $stmtUpdateRoomStatus = $conn->prepare($updateRoomStatusQuery);
                                        $stmtUpdateRoomStatus->bindParam(':roomId', $roomId, PDO::PARAM_INT);
                                        $stmtUpdateRoomStatus->execute();
                                    }

                                    // Redirect or display a success message
                                    header("Location: assign_doctor_to_patient.php");
                                    exit();
                                } else {
                                    echo "No available rooms with beds.";
                                }
                            } else {
                                echo "Patient is already assigned to a room.";
                            }
                        }
                        ?>



                        <form action="assign_patient_to_room.php" method="POST">
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <label for="patient_id">Select Patient:</label>
                                    <select class="form-control rounded-lg" name="patient_id" required>
                                        <?php
                                        // Fetch patients whose ID is not in the patient assignment table
                                        $fetchPatientsQuery = "SELECT * FROM patients WHERE patient_id NOT IN (SELECT patient_id FROM patient_assignments)";
                                        $stmtPatients = $conn->prepare($fetchPatientsQuery);
                                        $stmtPatients->execute();
                                        $patients = $stmtPatients->fetchAll(PDO::FETCH_ASSOC);

                                        foreach ($patients as $patient) {
                                            echo "<option value='{$patient['patient_id']}'>{$patient['first_name']} {$patient['last_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Other patient details inputs -->
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <button type="submit" class="btn btn-primary btn-user btn-block" name="assign_room">Assign Patient to Room</button>
                            </div>
                        </form>


                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            require_once "includes/footernote.php"
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php
    require_once "includes/footer.php"
    ?>

</body>

</html>