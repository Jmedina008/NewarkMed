<?php
require_once "includes/header.php"
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        require_once "includes/sidebar.php"
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                require_once "includes/navbar.php"
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="container">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Assign/Remove a Doctor to a Patient</h1>
                            <a href="assign_nurse_to_patient.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-users fa-sm text-white-50"></i> Assign/Remove a Nurse to a Patient</a>

                        </div>

                        <!-- Content Row -->
                        <?php
                        if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['assign_doctor'])) {
                            // Assume you have a valid database connection named $conn

                            // Get the selected patient and doctor IDs
                            $patientId = $_POST['patient_id'];
                            $doctorId = $_POST['doctor_id'];

                            // Update patient_assignments table to set has_doctor to 'yes'
                            $updatePatientAssignmentQuery = "UPDATE patient_assignments SET has_doctor = 'yes' WHERE patient_id = :patientId";
                            $stmtUpdatePatientAssignment = $conn->prepare($updatePatientAssignmentQuery);
                            $stmtUpdatePatientAssignment->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                            $stmtUpdatePatientAssignment->execute();

                            // Insert a new entry into doctor_assignments table
                            $insertDoctorAssignmentQuery = "INSERT INTO doctor_assignments (patient_id, doctor_id) VALUES (:patientId, :doctorId)";
                            $stmtInsertDoctorAssignment = $conn->prepare($insertDoctorAssignmentQuery);
                            $stmtInsertDoctorAssignment->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                            $stmtInsertDoctorAssignment->bindParam(':doctorId', $doctorId, PDO::PARAM_INT);
                            $stmtInsertDoctorAssignment->execute();

                            // Redirect or display a success message
                            header("Location: assign_nurse_to_patient.php");
                            exit();
                        }
                        ?>






                        <form action="assign_doctor_to_patient.php" method="POST">
                            <!-- Select patient with no doctor assigned -->
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <label for="patient_id">Select Patient:</label>
                                    <select class="form-control rounded-lg" name="patient_id" required>
                                        <?php
                                        // Fetch patients with no doctor assigned
                                        $fetchPatientsQuery = "SELECT pa.patient_id, p.first_name, p.last_name 
                              FROM patient_assignments pa
                              JOIN patients p ON pa.patient_id = p.patient_id
                              WHERE pa.has_doctor = 'no'";
                                        $stmtPatients = $conn->prepare($fetchPatientsQuery);
                                        $stmtPatients->execute();
                                        $patients = $stmtPatients->fetchAll(PDO::FETCH_ASSOC);

                                        foreach ($patients as $patient) {
                                            echo "<option value='{$patient['patient_id']}'>{$patient['first_name']} {$patient['last_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">

                                    <!-- Select doctor to assign -->
                                    <label for="doctor_id">Select Doctor:</label>
                                    <select class="form-control rounded-lg" name="doctor_id" required>
                                        <?php
                                        $fetchDoctorsQuery = "SELECT * FROM medical_staff WHERE job_type = 'Doctor'";
                                        $stmtDoctors = $conn->prepare($fetchDoctorsQuery);
                                        $stmtDoctors->execute();
                                        $doctors = $stmtDoctors->fetchAll(PDO::FETCH_ASSOC);

                                        foreach ($doctors as $doctor) {
                                            echo "<option value='{$doctor['staff_id']}'>{$doctor['first_name']} {$doctor['last_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <!-- Submit button -->
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <button type="submit" class="btn btn-primary btn-user btn-block" name="assign_doctor">Assign Doctor to Patient</button>
                            </div>
                        </form>


                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            require_once "includes/footernote.php"
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php
    require_once "includes/footer.php"
    ?>

</body>

</html>