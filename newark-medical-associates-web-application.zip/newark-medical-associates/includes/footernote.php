<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">

            <span>Copyright &copy;</span>
            <script>
                document.write(new Date().getFullYear());
            </script>
            Newark Medical Associates

        </div>
    </div>
</footer>