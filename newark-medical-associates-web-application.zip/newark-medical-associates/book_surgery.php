<?php
require_once "includes/header.php"
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        require_once "includes/sidebar.php"
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                require_once "includes/navbar.php"
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="container">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Book Surgery</h1>
                            <a href="view_patients.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-users fa-sm text-white-50"></i> View All Patient</a>

                        </div>

                        <!-- Content Row -->
                        <?php
                        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["book_surgery"])) {
                            // Validate and sanitize input data
                            $patientId = filter_input(INPUT_POST, 'patient_id', FILTER_VALIDATE_INT);
                            $surgeryDate = filter_input(INPUT_POST, 'surgery_date', FILTER_SANITIZE_STRING);

                            // You may want to add additional validation for the surgery date, e.g., ensure it is in the future, etc.

                            // Fetch doctor and nurse details from assignments tables
                            $fetchDoctorNurseQuery = "SELECT da.doctor_id, na.nurse_id 
                                                      FROM doctor_assignments da
                                                      JOIN nurse_assignments na ON da.patient_id = na.patient_id
                                                      WHERE da.patient_id = :patientId";

                            $stmtDoctorNurse = $conn->prepare($fetchDoctorNurseQuery);
                            $stmtDoctorNurse->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                            $stmtDoctorNurse->execute();
                            $doctorNurseDetails = $stmtDoctorNurse->fetch(PDO::FETCH_ASSOC);

                            if ($doctorNurseDetails) {
                                $doctorId = $doctorNurseDetails['doctor_id'];
                                $nurseId = $doctorNurseDetails['nurse_id'];

                                // Fetch room assigned to the patient
                                $fetchPatientRoomQuery = "SELECT room_id FROM patient_assignments WHERE patient_id = :patientId";

                                $stmtPatientRoom = $conn->prepare($fetchPatientRoomQuery);
                                $stmtPatientRoom->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                                $stmtPatientRoom->execute();
                                $patientRoom = $stmtPatientRoom->fetch(PDO::FETCH_ASSOC);

                                if ($patientRoom) {
                                    $roomId = $patientRoom['room_id'];

                                    // Insert surgery details into surgeries table
                                    $insertSurgeryQuery = "INSERT INTO surgeries (in_patient_id, room_id, surgeon_id, nurse_id, surgery_date) 
                                                           VALUES (:patientId, :roomId, :doctorId, :nurseId, :surgeryDate)";

                                    $stmtInsertSurgery = $conn->prepare($insertSurgeryQuery);
                                    $stmtInsertSurgery->bindParam(':patientId', $patientId, PDO::PARAM_INT);
                                    $stmtInsertSurgery->bindParam(':roomId', $roomId, PDO::PARAM_INT);
                                    $stmtInsertSurgery->bindParam(':doctorId', $doctorId, PDO::PARAM_INT);
                                    $stmtInsertSurgery->bindParam(':nurseId', $nurseId, PDO::PARAM_INT);
                                    $stmtInsertSurgery->bindParam(':surgeryDate', $surgeryDate, PDO::PARAM_STR);

                                    if ($stmtInsertSurgery->execute()) {
                                        // Redirect or display success message
                                        echo '<div class="alert alert-success" role="alert">
                                Surgery Booking successfully!</div>';
                                        exit();
                                    } else {
                                        // Handle insertion failure
                                        echo "Failed to book surgery. Please try again.";
                                    }
                                } else {
                                    // Handle missing room assignment
                                    echo "Patient does not have a room assigned.";
                                }
                            } else {
                                // Handle missing doctor or nurse assignment
                                echo "Patient does not have a doctor or nurse assigned.";
                            }
                        } else {
                            // Handle invalid request or missing form submission
                            echo "Invalid request.";
                        }
                        ?>



                        <form class="user" action="book_surgery.php" method="POST">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="patient">Select Patient:</label>
                                    <select class="form-control rounded-lg" name="patient_id" required>
                                        <?php
                                        // Fetch patients with doctor and nurse assigned but not booked for surgery
                                        $fetchPatientsQuery = "SELECT pa.patient_id, p.first_name, p.last_name 
                              FROM doctor_assignments da
                              JOIN nurse_assignments na ON da.patient_id = na.patient_id
                              JOIN patient_assignments pa ON da.patient_id = pa.patient_id
                              JOIN patients p ON pa.patient_id = p.patient_id
                              WHERE pa.has_doctor = 'yes' 
                              AND pa.has_nurse = 'yes'
                              AND pa.patient_id NOT IN (SELECT in_patient_id FROM surgeries)";
                                        $stmtPatients = $conn->prepare($fetchPatientsQuery);
                                        $stmtPatients->execute();
                                        $patients = $stmtPatients->fetchAll(PDO::FETCH_ASSOC);

                                        if ($patients) {
                                            foreach ($patients as $patient) {
                                                echo "<option value='{$patient['patient_id']}'>{$patient['first_name']} {$patient['last_name']}</option>";
                                            }
                                        } else {
                                            echo "<option value='' disabled>No patients available</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="form-group">

                                    <label for="surgery_date">Select Surgery Date and Time:</label>
                                    <input type="datetime-local" class="form-control" id="surgery_date" name="surgery_date" required>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block" name="book_surgery">
                                    <b>Book Surgery</b>
                                </button>
                            </div>
                        </form>

                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            require_once "includes/footernote.php"
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php
    require_once "includes/footer.php"
    ?>

</body>

</html>