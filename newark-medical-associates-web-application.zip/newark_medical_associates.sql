-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 08, 2023 at 08:42 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newark_medical_associates`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `patient_id`, `doctor_id`, `appointment_date`) VALUES
(1, 1, 1, '2023-12-06 20:05:00'),
(2, 2, 3, '2023-12-10 22:10:00'),
(3, 2, 3, '2023-12-10 22:10:00'),
(4, 2, 3, '2023-12-10 22:10:00'),
(5, 2, 3, '2023-12-10 22:10:00'),
(6, 2, 3, '2023-12-10 22:10:00'),
(7, 4, 1, '2023-12-03 20:23:00'),
(8, 4, 1, '2023-12-03 20:23:00');

-- --------------------------------------------------------

--
-- Table structure for table `diagnoses`
--

CREATE TABLE `diagnoses` (
  `diagnosis_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `diagnosis_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `doctor_assignments`
--

CREATE TABLE `doctor_assignments` (
  `assignment_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `assigned_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor_assignments`
--

INSERT INTO `doctor_assignments` (`assignment_id`, `doctor_id`, `patient_id`, `assigned_date`) VALUES
(1, 1, 3, '2023-12-08 06:40:24');

-- --------------------------------------------------------

--
-- Table structure for table `in_patients`
--

CREATE TABLE `in_patients` (
  `in_patient_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `nurse_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `medical_history`
--

CREATE TABLE `medical_history` (
  `history_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `diagnosis` varchar(255) DEFAULT NULL,
  `illness` varchar(255) DEFAULT NULL,
  `date_recorded` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medical_history`
--

INSERT INTO `medical_history` (`history_id`, `patient_id`, `diagnosis`, `illness`, `date_recorded`) VALUES
(1, 1, 'Hypertension', 'High blood pressure', '2022-01-15'),
(2, 1, 'Type 2 Diabetes', 'Elevated blood sugar levels', '2022-02-20'),
(3, 2, 'Migraine', 'Recurrent severe headaches', '2022-03-10'),
(4, 3, 'Asthma', 'Chronic respiratory condition', '2022-04-05'),
(5, 3, 'Allergic Rhinitis', 'Allergies affecting the nose', '2022-05-12');

-- --------------------------------------------------------

--
-- Table structure for table `medical_staff`
--

CREATE TABLE `medical_staff` (
  `staff_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `job_type` enum('Doctor','Nurse') NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medical_staff`
--

INSERT INTO `medical_staff` (`staff_id`, `first_name`, `last_name`, `job_type`, `phone_number`) VALUES
(1, 'Ben', 'Charles', 'Doctor', '9487588845'),
(2, 'Sylvia', 'Paulson', 'Nurse', '559900045'),
(3, 'Great', 'George', 'Doctor', '747747774');

-- --------------------------------------------------------

--
-- Table structure for table `nurse_assignments`
--

CREATE TABLE `nurse_assignments` (
  `assignment_id` int(11) NOT NULL,
  `nurse_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `assigned_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nurse_assignments`
--

INSERT INTO `nurse_assignments` (`assignment_id`, `nurse_id`, `patient_id`, `assigned_date`) VALUES
(1, 2, 3, '2023-12-08 06:51:57');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `first_name`, `last_name`, `dob`, `gender`, `email`, `phone_number`, `address`, `registration_date`) VALUES
(1, 'James', 'Mark', '1997-01-29', 'Male', 'jamesmark@gmail.com', '07060728405', '44 Waterworks Street', '2023-12-07 17:32:24'),
(2, 'Chioma', 'Omega', '2005-01-04', 'Female', 'chiomaomega@gmail.com', '08126508278', '44 obafemi awolowo university', '2023-12-07 17:33:40'),
(3, 'Keneth', 'Obasi', '2012-02-09', 'Male', 'zubbysureboysmart@gmail.com', '07087878987', 'Obafemi Omada', '2023-12-07 17:40:23'),
(4, 'Kay', 'Micheal', '2004-01-07', 'Male', 'kay@gmail.com', '07060728405', '16 Mortimer Street', '2023-12-07 17:46:49');

-- --------------------------------------------------------

--
-- Table structure for table `patient_assignments`
--

CREATE TABLE `patient_assignments` (
  `assignment_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `assigned_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `has_doctor` enum('yes','no') NOT NULL DEFAULT 'no',
  `has_nurse` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_assignments`
--

INSERT INTO `patient_assignments` (`assignment_id`, `patient_id`, `room_id`, `assigned_date`, `has_doctor`, `has_nurse`) VALUES
(1, 3, 1, '2023-12-08 02:12:46', 'yes', 'yes'),
(2, 2, 1, '2023-12-08 02:14:50', 'no', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_id` int(11) NOT NULL,
  `room_number` varchar(10) NOT NULL,
  `bed_count` int(11) NOT NULL,
  `available_beds` int(11) NOT NULL,
  `status` enum('Available','Occupied') DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `room_number`, `bed_count`, `available_beds`, `status`) VALUES
(1, '101', 2, 0, 'Occupied'),
(2, '102', 3, 3, 'Available'),
(3, '103', 2, 1, 'Available'),
(4, '201', 4, 4, 'Available'),
(5, '202', 2, 0, 'Occupied'),
(6, '203', 3, 2, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `shifts`
--

CREATE TABLE `shifts` (
  `shift_id` int(11) NOT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `shift_start` datetime DEFAULT NULL,
  `shift_end` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `surgeries`
--

CREATE TABLE `surgeries` (
  `surgery_id` int(11) NOT NULL,
  `in_patient_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `surgeon_id` int(11) DEFAULT NULL,
  `nurse_id` int(11) DEFAULT NULL,
  `surgery_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `diagnoses`
--
ALTER TABLE `diagnoses`
  ADD PRIMARY KEY (`diagnosis_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `doctor_assignments`
--
ALTER TABLE `doctor_assignments`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `in_patients`
--
ALTER TABLE `in_patients`
  ADD PRIMARY KEY (`in_patient_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `nurse_id` (`nurse_id`);

--
-- Indexes for table `medical_history`
--
ALTER TABLE `medical_history`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `medical_staff`
--
ALTER TABLE `medical_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `nurse_assignments`
--
ALTER TABLE `nurse_assignments`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `nurse_id` (`nurse_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `patient_assignments`
--
ALTER TABLE `patient_assignments`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `shifts`
--
ALTER TABLE `shifts`
  ADD PRIMARY KEY (`shift_id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `surgeries`
--
ALTER TABLE `surgeries`
  ADD PRIMARY KEY (`surgery_id`),
  ADD KEY `in_patient_id` (`in_patient_id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `surgeon_id` (`surgeon_id`),
  ADD KEY `nurse_id` (`nurse_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `diagnoses`
--
ALTER TABLE `diagnoses`
  MODIFY `diagnosis_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctor_assignments`
--
ALTER TABLE `doctor_assignments`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `in_patients`
--
ALTER TABLE `in_patients`
  MODIFY `in_patient_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medical_history`
--
ALTER TABLE `medical_history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `medical_staff`
--
ALTER TABLE `medical_staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `nurse_assignments`
--
ALTER TABLE `nurse_assignments`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patient_assignments`
--
ALTER TABLE `patient_assignments`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `shifts`
--
ALTER TABLE `shifts`
  MODIFY `shift_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `surgeries`
--
ALTER TABLE `surgeries`
  MODIFY `surgery_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `medical_staff` (`staff_id`);

--
-- Constraints for table `diagnoses`
--
ALTER TABLE `diagnoses`
  ADD CONSTRAINT `diagnoses_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `doctor_assignments`
--
ALTER TABLE `doctor_assignments`
  ADD CONSTRAINT `doctor_assignments_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `medical_staff` (`staff_id`),
  ADD CONSTRAINT `doctor_assignments_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `in_patients`
--
ALTER TABLE `in_patients`
  ADD CONSTRAINT `in_patients_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  ADD CONSTRAINT `in_patients_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`),
  ADD CONSTRAINT `in_patients_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `medical_staff` (`staff_id`),
  ADD CONSTRAINT `in_patients_ibfk_4` FOREIGN KEY (`nurse_id`) REFERENCES `medical_staff` (`staff_id`);

--
-- Constraints for table `medical_history`
--
ALTER TABLE `medical_history`
  ADD CONSTRAINT `medical_history_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `nurse_assignments`
--
ALTER TABLE `nurse_assignments`
  ADD CONSTRAINT `nurse_assignments_ibfk_1` FOREIGN KEY (`nurse_id`) REFERENCES `medical_staff` (`staff_id`),
  ADD CONSTRAINT `nurse_assignments_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Constraints for table `patient_assignments`
--
ALTER TABLE `patient_assignments`
  ADD CONSTRAINT `patient_assignments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  ADD CONSTRAINT `patient_assignments_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`);

--
-- Constraints for table `shifts`
--
ALTER TABLE `shifts`
  ADD CONSTRAINT `shifts_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `medical_staff` (`staff_id`);

--
-- Constraints for table `surgeries`
--
ALTER TABLE `surgeries`
  ADD CONSTRAINT `surgeries_ibfk_1` FOREIGN KEY (`in_patient_id`) REFERENCES `in_patients` (`in_patient_id`),
  ADD CONSTRAINT `surgeries_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`),
  ADD CONSTRAINT `surgeries_ibfk_3` FOREIGN KEY (`surgeon_id`) REFERENCES `medical_staff` (`staff_id`),
  ADD CONSTRAINT `surgeries_ibfk_4` FOREIGN KEY (`nurse_id`) REFERENCES `medical_staff` (`staff_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
